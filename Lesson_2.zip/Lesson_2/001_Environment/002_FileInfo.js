// __dirname - глобальная переменная, хранит имя текущей директории
console.log("Directory name:", __dirname);


// __filename - глобальная переменная, хранит имя текущего файла
console.log("File name:", __filename);