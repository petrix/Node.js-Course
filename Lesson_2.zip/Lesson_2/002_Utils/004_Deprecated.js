var func = require('./example');

// func.oF();

func.nF();

