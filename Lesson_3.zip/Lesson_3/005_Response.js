const express = require('express'); 
const path = require('path'); 

const app = express(); 

const port = 8080; 

app.get('/', function(req, res) { 

	// метод cookie позволяет создавать cookies 
	res.cookie('someCookie', 'this is a cookie', {
		httpOnly: true,
        maxAge: 2000
	}); 
	res.cookie('anotherCookie', 'this is another cookie!'); 

	// удалить cookie 
	res.clearCookie('anotherCookie'); 

	// метод sendFile позволяет указывать в ответе файл для чтения браузером 
	res.sendFile(path.join(__dirname,'/data/007_index.html')); 
}); 

app.listen(port, function() {
	console.log('app running on port ' + port); 
}); 