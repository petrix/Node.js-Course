const express = require('express');
const app = express();

app.listen(8080, function(){
    console.log('server start on port 8080');
})